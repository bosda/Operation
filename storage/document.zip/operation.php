<?php

return [
	'token' => '******',

    'report' => env('APP_OPERATION_REPORT', false),
];
